// src/models/Experience.ts

export interface Experience {
    ExperienceID?: number;     // Optional vì ID sẽ được tự động tạo khi thêm mới
    ExperienceName: string;    // Bắt buộc, để lưu tên kinh nghiệm
}
