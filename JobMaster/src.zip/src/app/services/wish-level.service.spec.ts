import { TestBed } from '@angular/core/testing';

import { WishLevelService } from './wish-level.service';

describe('WishLevelService', () => {
  let service: WishLevelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WishLevelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
