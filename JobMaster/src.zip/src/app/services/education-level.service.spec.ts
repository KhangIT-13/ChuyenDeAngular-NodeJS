import { TestBed } from '@angular/core/testing';

import { EducationLevelService } from './education-level.service';

describe('EducationLevelService', () => {
  let service: EducationLevelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EducationLevelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
