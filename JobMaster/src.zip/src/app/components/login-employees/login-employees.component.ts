import { Component } from '@angular/core';

@Component({
  selector: 'app-login-employees',
  standalone: true,
  imports: [],
  templateUrl: './login-employees.component.html',
  styleUrl: './login-employees.component.css'
})
export class LoginEmployeesComponent {

}
