// src/models/JobCategoryMapping.ts

export interface JobCategoryMapping {
    JobCategoryID?: number;  // Optional vì ID sẽ tự động được tạo khi thêm mới
    JobID: number;           // Bắt buộc, ID của công việc
    CategoryID: number;      // Bắt buộc, ID của danh mục
}
