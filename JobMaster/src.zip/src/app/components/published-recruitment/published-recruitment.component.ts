import { Component } from '@angular/core';

@Component({
  selector: 'app-published-recruitment',
  standalone: true,
  imports: [],
  templateUrl: './published-recruitment.component.html',
  styleUrl: './published-recruitment.component.css'
})
export class PublishedRecruitmentComponent {

}
