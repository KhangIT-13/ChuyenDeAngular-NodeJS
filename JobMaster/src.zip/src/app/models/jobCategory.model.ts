// src/models/JobCategory.ts

export interface JobCategory {
    CategoryID?: number;       // Optional vì ID sẽ được tự động tạo khi thêm mới
    CategoryName: string;      // Bắt buộc và unique, tên danh mục công việc
}
