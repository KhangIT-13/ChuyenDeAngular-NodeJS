import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Job } from '../models/job.model'; // Import model của Job, bạn cần tạo file model này

@Injectable({
  providedIn: 'root'
})
export class JobService {
  private apiUrl = 'http://localhost:3105/jobs'; // Đặt URL API backend của bạn ở đây

  constructor(private http: HttpClient) {}

  // Lấy danh sách việc làm
  getJobs(): Observable<Job[]> {
    return this.http.get<Job[]>(this.apiUrl);
  }

  // Lấy chi tiết công việc theo ID
  getJobById(id: number): Observable<Job> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.get<Job>(url);
  }

  // Thêm công việc mới
  addJob(job: Job): Observable<Job> {
    return this.http.post<Job>(this.apiUrl, job, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    });
  }

  // Cập nhật công việc
  updateJob(id: number, job: Job): Observable<Job> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.put<Job>(url, job, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    });
  }

  // Xóa công việc
  deleteJob(id: number): Observable<void> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.delete<void>(url);
  }
}
