// src/models/JobReview.ts

export interface JobReview {
    ReviewID?: number;        // Optional vì ID sẽ tự động được tạo khi thêm mới
    JobID: number;           // Bắt buộc, ID của công việc được đánh giá
    UserID: number;          // Bắt buộc, ID của người dùng viết đánh giá
    Rating: number;          // Bắt buộc, đánh giá từ 1 đến 5
    Comment?: string;        // Optional, có thể để trống nếu không có nhận xét
    CreatedAt?: Date;        // Optional vì backend sẽ tự động set giá trị hiện tại
}
