import { Component } from '@angular/core';

@Component({
  selector: 'app-register-employers',
  standalone: true,
  imports: [],
  templateUrl: './register-employers.component.html',
  styleUrl: './register-employers.component.css'
})
export class RegisterEmployersComponent {

}
