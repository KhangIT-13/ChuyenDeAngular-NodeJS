// src/models/CurrentLevel.ts

export interface CurrentLevel {
    CurrentLevelID?: number;   // Optional vì sẽ được backend tự động tạo khi thêm mới
    CurrentLevelName: string;  // Bắt buộc, đại diện cho tên cấp độ hiện tại
}
