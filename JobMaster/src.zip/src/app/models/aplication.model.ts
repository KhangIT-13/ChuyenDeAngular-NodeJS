// src/models/Application.ts

export interface Application {
    ApplicationID?: number;  // Có thể là optional vì có thể không có khi tạo mới
    JobID: number;
    UserID: number;
    ResumeID?: number;
    AppliedAt?: Date;  // Dữ liệu này thường có thể optional vì có default là ngày hiện tại ở backend
    Status: string;
}
