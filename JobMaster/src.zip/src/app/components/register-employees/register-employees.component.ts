import { Component } from '@angular/core';

@Component({
  selector: 'app-register-employees',
  standalone: true,
  imports: [],
  templateUrl: './register-employees.component.html',
  styleUrl: './register-employees.component.css'
})
export class RegisterEmployeesComponent {

}
