// src/models/Province.ts

export interface Province {
    ProvinceID?: number;       // Optional vì ID sẽ tự động được tạo khi thêm mới
    ProvinceName: string;      // Bắt buộc, đại diện cho tên tỉnh
}
