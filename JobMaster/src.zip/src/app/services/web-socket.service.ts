// web-socket.service.ts
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { io } from 'socket.io-client';

@Injectable({
  providedIn: 'root'
})
export class WebSocketService {
  socket: any;
  readonly url: string = 'http://localhost:3000'; // Địa chỉ của server Socket.IO

  constructor() {
    this.socket = io(this.url, {
      transports: ['websocket'], // Chỉ định sử dụng giao thức WebSocket
    });
  }

  listen(eventName: string): Observable<any> {
    return new Observable((subscriber) => {
      this.socket.on(eventName, (data: any) => {
        subscriber.next(data);
      });
    });
  }

  emit(eventName: string, data: any): void {
    this.socket.emit(eventName, data);
  }
}
