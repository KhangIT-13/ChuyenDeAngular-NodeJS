// src/models/EducationLevel.ts

export interface EducationLevel {
    EducationLevelID?: number;        // Optional vì ID sẽ được backend tự động tạo khi thêm mới
    EducationLevelName: string;       // Bắt buộc vì tên trình độ học vấn không thể để trống
}
