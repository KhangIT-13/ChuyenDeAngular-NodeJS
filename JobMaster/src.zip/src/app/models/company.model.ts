// src/models/Company.ts

export interface Company {
    CompanyID?: number;            // Optional vì ID sẽ tự động được tạo ở backend khi thêm mới
    CompanyName: string;
    Description?: string;          // Optional vì có thể không có mô tả
    Website?: string;              // Optional, có thể trống, với validate URL nếu cần thiết
    Location?: string;             // Optional, có thể không có thông tin vị trí
    Industry?: string;             // Optional, mô tả lĩnh vực hoạt động
    EmployeeCount?: number;        // Optional vì có thể không có dữ liệu
    Logo?: string;                 // Optional, đường dẫn ảnh logo
    CreatedAt?: Date;              // Optional vì backend sẽ set mặc định khi tạo mới
    UpdatedAt?: Date;              // Optional vì backend sẽ tự động cập nhật
}
