import { TestBed } from '@angular/core/testing';

import { JobCategoryMappingService } from './job-category-mapping.service';

describe('JobCategoryMappingService', () => {
  let service: JobCategoryMappingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JobCategoryMappingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
