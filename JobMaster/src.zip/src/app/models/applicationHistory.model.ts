// src/models/ApplicationHistory.ts

export interface ApplicationHistory {
    HistoryID?: number;  // Có thể là optional vì sẽ được backend tự động tạo khi thêm lịch sử mới
    ApplicationID: number;
    Status: string;
    ChangedAt?: Date;  // Optional vì backend sẽ set giá trị hiện tại nếu không được cung cấp
}
