export interface Job {
  JobID: number;           
  CompanyID: number;       
  Title: string;           
  Description: string;     
  Location: string;        
  Salary?: number;         
  PostedAt?: Date;         
  Status: string;          
}
