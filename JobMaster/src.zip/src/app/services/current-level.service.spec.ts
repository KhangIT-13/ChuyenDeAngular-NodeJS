import { TestBed } from '@angular/core/testing';

import { CurrentLevelService } from './current-level.service';

describe('CurrentLevelService', () => {
  let service: CurrentLevelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CurrentLevelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
