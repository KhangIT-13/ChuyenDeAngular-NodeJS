import { Component, NgModule, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { Job } from '../../models/job.model';
import { JobService } from '../../services/job.service';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-home',
  standalone: true,
  imports: [HttpClientModule, CommonModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
  jobs: Job[] = [];
  loading: boolean = false;
  errorMessage: string = '';

  constructor(private jobService: JobService) {}

  ngOnInit(): void {
    this.getJobs();
    
  }

  getJobs(): void {
    this.loading = true;
    this.jobService.getJobs().subscribe(
      (jobs) => {
        this.jobs = jobs;
        this.loading = false;
        console.log(this.jobs) // trong hàm
      },
      (error) => {
        this.loading = false;
        this.errorMessage = 'Could not load jobs. Please try again later.';
        console.error(error); // Log lỗi cho phát triển
      }
    );
  }
}
