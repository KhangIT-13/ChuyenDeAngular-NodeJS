import { TestBed } from '@angular/core/testing';

import { JobReviewService } from './job-review.service';

describe('JobReviewService', () => {
  let service: JobReviewService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JobReviewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
