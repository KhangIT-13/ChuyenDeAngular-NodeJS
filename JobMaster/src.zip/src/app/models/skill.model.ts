// src/models/Skill.ts

export interface Skill {
    SkillID?: number;       // Optional vì ID sẽ tự động được tạo khi thêm mới
    SkillName: string;      // Bắt buộc và unique, tên của kỹ năng
}
