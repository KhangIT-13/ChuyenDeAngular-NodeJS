// src/models/ChatRoom.ts

export interface ChatRoom {
    RoomID?: number;           // Optional vì sẽ được backend tự động tạo khi thêm phòng chat mới
    User1ID: number;
    User2ID: number;
    LastMessage?: string;       // Optional vì phòng mới có thể chưa có tin nhắn
    LastMessageTime?: Date;     // Optional vì có thể chưa có tin nhắn hoặc sẽ có mặc định từ backend
}
