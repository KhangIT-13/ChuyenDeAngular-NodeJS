// src/models/Resume.ts

export interface Resume {
    ResumeID?: number;        // Optional vì ID sẽ tự động được tạo khi thêm mới
    UserID: number;          // Bắt buộc, ID của người dùng sở hữu hồ sơ
    Summary?: string;        // Optional, tóm tắt về hồ sơ
    Skills?: string;         // Optional, danh sách kỹ năng
    Experience?: string;     // Optional, kinh nghiệm làm việc
    Education?: string;      // Optional, trình độ học vấn
    CreatedAt?: Date;        // Optional, sẽ được tự động thiết lập bởi backend
}
