// src/models/Chat.ts

export interface Chat {
    ChatID?: number;        // Optional vì sẽ được tự động tạo khi thêm mới
    RoomID: number;
    SenderID: number;
    Message: string;
    SentAt?: Date;          // Optional vì mặc định là ngày hiện tại
    IsRead?: boolean;       // Optional vì mặc định là false khi tạo mới
}
