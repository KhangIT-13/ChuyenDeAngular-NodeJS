import { AfterViewInit, Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [],
  templateUrl: './search.component.html',
  styleUrls: ['search.component.css'],
})
export class SearchComponent implements OnInit, AfterViewInit {
  
  constructor() {}

  ngOnInit() {
    // logic for initialization
  }

  ngAfterViewInit() {
    // logic that depends on view being fully initialized
  }
}