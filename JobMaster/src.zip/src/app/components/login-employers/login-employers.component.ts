import { Component } from '@angular/core';

@Component({
  selector: 'app-login-employers',
  standalone: true,
  imports: [],
  templateUrl: './login-employers.component.html',
  styleUrl: './login-employers.component.css'
})
export class LoginEmployersComponent {

}
