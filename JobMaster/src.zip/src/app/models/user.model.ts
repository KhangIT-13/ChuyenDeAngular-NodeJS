// src/models/User.ts

export interface User {
    UserID?: number;          // Optional vì ID sẽ tự động được tạo khi thêm mới
    UserName: string;         // Bắt buộc và unique, tên đăng nhập của người dùng
    Password: string;         // Bắt buộc, mật khẩu của người dùng
    Email: string;            // Bắt buộc và unique, địa chỉ email của người dùng
    Role: string;             // Bắt buộc, vai trò của người dùng (ví dụ: ứng viên, nhà tuyển dụng)
    CreatedAt?: Date;         // Optional, thời gian người dùng được tạo sẽ tự động thiết lập
}
