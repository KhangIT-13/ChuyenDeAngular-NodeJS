// src/models/ResumeSkill.ts

export interface ResumeSkill {
    ResumeSkillID?: number;   // Optional vì ID sẽ tự động được tạo khi thêm mới
    ResumeID: number;         // Bắt buộc, ID của hồ sơ mà kỹ năng thuộc về
    SkillID: number;          // Bắt buộc, ID của kỹ năng
}
