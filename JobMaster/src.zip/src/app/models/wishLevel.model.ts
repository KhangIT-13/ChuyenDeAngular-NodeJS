// src/models/WishLevel.ts

export interface WishLevel {
    WishLevelID?: number;     // Optional vì ID sẽ tự động được tạo khi thêm mới
    WishLevelName: string;    // Bắt buộc, tên của mức độ mong muốn
}
