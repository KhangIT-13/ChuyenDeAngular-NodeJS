import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router'
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  isHomePage: boolean = false;  // Biến để kiểm tra nếu đang ở trang home

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Theo dõi sự thay đổi của route
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        // Kiểm tra nếu route hiện tại là '/home'
        const currentUrl = this.router.url;
        this.isHomePage = currentUrl === '/search' || currentUrl ==='/jobdetail' || currentUrl ==='/jobsearch'|| currentUrl ==='/published'|| currentUrl ==='/chat';
        console.log(this.isHomePage);
      }
    });
  }
}
